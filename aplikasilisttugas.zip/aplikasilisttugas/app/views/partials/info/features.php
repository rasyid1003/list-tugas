<div class="container">
	<h4>Features</h4>
	<hr />
	<div>
		Put page content here
	</div>
	<?php
	if (DEVELOPMENT_MODE) {
	?>
		<small class="text-muted">To edit this file, browse to :- <i>app/view/partials/info/features.php</i></small>
	<?php
	}
	?>

</div>